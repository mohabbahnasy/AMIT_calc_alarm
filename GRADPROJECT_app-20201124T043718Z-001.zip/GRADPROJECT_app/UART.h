/*
 * UART.h
 *
 * Created: 4/27/2018 5:00:21 PM
 *  Author: Mohab
 */ 


#ifndef UART_H_
#define UART_H_
#include <avr/io.h>
# include "std_macro.h"
# include "ADC.h"

void UART_init();
void UART_send(uint8_t data);
uint8_t UART_res();


#endif /* UART_H_ */