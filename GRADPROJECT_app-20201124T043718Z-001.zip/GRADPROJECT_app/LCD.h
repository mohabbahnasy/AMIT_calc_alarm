/*
 * LCD.h
 *
 * Created: 4/21/2018 5:07:43 PM
 *  Author: Mohab
 */ 


#ifndef LCD_H_
#define LCD_H_

#include <avr/io.h>
# include "std_macro.h"
//# include "ADC.h"
//#include "PWM.h"
# define LCD_INIT_DIR(x) DDRB|= 0b1110; DDRA|=0b11110000;
#define LCD_RS(x)  if (x == 0) CLEARBIT(PORTB,1);else SETBIT(PORTB,1);
# define LCD_EN(x) if (x ==0 ) CLEARBIT(PORTB,3);else SETBIT(PORTB,3);
# define LCD_RW(x) if (x==0) CLEARBIT(PORTB,2);else SETBIT(PORTB,2);
# define  LCD_D7(x)  if (x==0) CLEARBIT(PORTA,7);else SETBIT(PORTA,7);
# define  LCD_D6(x)  (x==0)? (CLEARBIT(PORTA,6)): (SETBIT(PORTA,6));
# define  LCD_D5(x)  (x==0)? (CLEARBIT(PORTA,5)): (SETBIT(PORTA,5));
# define  LCD_D4(x)  (x==0)? (CLEARBIT(PORTA,4)): (SETBIT(PORTA,4));



void LCD_init();
void LCD_write_cmd(uint8_t cmd);
void LCD_write_char(uint8_t data);
void LCD_write_string(uint8_t *data);
void LCD_write_number(uint16_t number);
void LCD_write_number_float(uint16_t number);
//void LCD_write_number(float number);


#endif /* LCD_H_ */