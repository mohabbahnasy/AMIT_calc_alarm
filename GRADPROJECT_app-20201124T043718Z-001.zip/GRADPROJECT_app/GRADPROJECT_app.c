/*
 * GRADPROJECT_app.c
 *
 * Created: 5/11/2018 1:10:40 PM
 *  Author: Mohab
 */ 

/* 
application details:
--------------------------------------------------------------------------------------------------------------------------
this application has three modes:
	mode 1: is fire alarm system
	mode 2: is Auto Lighting system
	mode 3: is 2 digits numbers ca;cualator
--------------------------------------------------------------------------------------------------------------------------
How to use this application:
after burning the code on the AMIT kit with atmega 32 the following will happen.
	- when you push the push button for the first time the LCD will write "READY".
	- when you push the push button for the second time the LCD will write "mode 1" and mode 1 will run.
	- for the third time mode 2 will run and mode 2 will be written on the LCD.
	- for the fourth time LCD will write "mode 3" for 500 ms only than the calculator will be run.
	- to avoid any errors push on before starting to calculate(it will work correctly with out this step most of the time)
	- this calculator can apply (+,*,/,-) arithmatic operation between 2 digits number to an other 2 digits number only
	- if you push the push button for more one time the word "end" will be  written.
	- after that, if you push for one more time the word ready will be written and so on.
-------------------------------------------------------------------------------------------------------------------------

if you have any question or advices please contact me

eng.mohab.a.bahnasy@gmail.com
+201008469306


*/

#include "GRADPROJECT.h"
# include "std_macro.h"
 uint8_t count=0,mode=0;
int main(void)
{
	
	LCD_init(); // initialization of LCD
	UART_init(); // initialization of UART
	
	SREG|=(1<<7); // general interrupt enable
	GICR|=(1<<6); // INT0 interrupt enable
	MCUCR|=(1<<ISC01)|(1<<ISC00); //Raising edge for interrupt
	DDRD|=1<<7 | 1<<3; //led 3 enable - relay enable 
    while(1)
    {
		
	CLEARBIT(DDRD,5); // to make sure that the led is not on
	CLEARBIT(DDRD,3); // to make sure that the relay is not on
	CLEARBIT(DDRD,4); // to make sure that the buzzer is not on
		
		mode=UART_res(); // to receive the value that is sent by UART send from the interrupt function 
		//mode 0-----------------------------------------------------------------------------------------------------------
		if(mode==0)  // after the first push
			{
				LCD_write_cmd(0x01); // to clear LCD
				LCD_write_string("Ready");
				
			}
		// mode1 ----------------------------------------------------------------------------------------------------------
		else if(mode==1) // after the second push to operate the mode 1 (fire alarm depending on ADC 1)
		{
			LCD_write_cmd(0x01);  // clear LCD
			LCD_write_string("mode1");
			PWM1_OCR1AB_init(); // initialization of the two outputs of PWM (for LED and for Buzzer to make the alarm)(OCR1A or the Led and OCRB for Buzzer)
			
			DDRD|= 1<<4 | 1<<5; // LED and BUZZER output
			
			//----------------------------------------------------------------------------------------
			//while loop for mode 1
			
			while (mode==1)
			{
				ADC_init_1(); // initialization of ADC 1 potentiometer as a simulation of variable thermal resistance(it may need to change the pre scalur value) 
				LCD_write_cmd(0xc0); // to write in the second line in LCD
				LCD_write_number(ADC_Read_1(0));
				//------------------------------------------------
				// duty cycle ranges for alarm
				if (ADC_Read_1(0)<250) // first zone no alarm
				{
						
						PWM1_OCR1AB_duty_cycle(0);
						
					
				}
				else if ((ADC_Read_1(0)>=250)&&(ADC_Read_1(0)<500)) // second zone low sound and low light
				{ 
					
					PWM1_OCR1AB_duty_cycle(30);
					
				}
				else if ((ADC_Read_1(0)>=500)&&(ADC_Read_1(0)<750)) //// third zone mid low sound and mid low light
				{
					
					PWM1_OCR1AB_duty_cycle(75);
					
				}
					
				else // fourth zone high sound and high light
				{	
					PWM1_OCR1AB_duty_cycle(100);
					
				}	// end of if ADC READ 1
							
			} // end of while mode ==1
			
			
		} // end of if mode ==1
		
		
		// mode 2 ----------------------------------------------------------------------------------------
	     else if(mode==2)  // after the third push to operate the mode 2 (Auto Light system)
		{
			ADC_init_0(); // ADC 0 initialization LDR
			LCD_write_cmd(0x01); // write on the first line LCD
			LCD_write_string("mode2"); 
			DDRD|=(1<<3); // output for the relay
			
			// while loop for mode 2
			while(mode==2)
			{LCD_write_cmd(0xc0); // write in the second line in mode 2
				LCD_write_number(ADC_Read_0(0)); // write the number of ADC in second line
				
				
				if ((ADC_Read_0(0))>300) 
				{
					SETBIT(PORTD,3);  //light off because the lamp is connected to normally closed 
				}
				else
				{
					CLEARBIT(PORTD,3);  // light is on because it is connected to normally closed
				} // end of if ADC_Read_0
				
			}	// end of while mode ==2		
		} // end of if mode ==2
		
		// mode3----------------------------------------------------------------------------------------------
		else if(mode==3) // calculator +, -, *, / arithmatic operations between 2 digits number and an other 2 dgits number.
		{
			LCD_write_cmd(0x01); // clear LCD
			LCD_write_string("mode3"); 
			_delay_ms(500); // this delay is to keep "mode 3" written for half a seconded
			
				key_pad_init(); // initialization of key pad to be used as calculator.
				
				LCD_write_cmd(0x01); // clear LCD
				uint16_t num1tim10,num1tim1,num2tim10,num2tim1,num1,num2,minus;
				/*
				num1tim10	: the tens of the first number
				num1tim1	: the units of the first number
				num2tim10	: the tens of the second number
				num2tim1	: the units of the second number  
				*/
				float res,all_digits;
				/*
				res : result of the operation
				all_digit: the result of the division multiplied by 100 (revise it in  (/) section)
				*/
				char operation;
				// +,-.*,/
				uint8_t count=0;
				/* count for the digit that written on LCD as  
				first number tens 1,
				first number units 2,
				operation char 3,
				second number tens 4,
				second number units 5,
				the = sign 6,
				if the 6th chr isn't = an error will be printed
				*/
				LCD_write_cmd(0x80); //write in the line without clear
				uint8_t data=0;// data is the written item from key pad
				// while loop for mode 3
				while(mode==3)
				{//SETBIT(PINC,0); 
					
					data= key_pad_scan(); // to scan the entered character from key pad
					_delay_ms(10);// to avoid re bouncing 
					
					//while (((READBIT(PINC,0))!=1) || ((READBIT(PINC,1))!=1) || ((READBIT(PINC,2))!=1) || ((READBIT(PINC,3))!=1));
					while (((!READBIT(PINC,0))) || ((!READBIT(PINC,1))) || ((!READBIT(PINC,2))) || ((!READBIT(PINC,3)))); // latch
					
					_delay_ms(100);// by try and error to avoid hard ware error on the kit
					
					
					if (data!=100) // 100 if no data is entered the key pad function returns 100
					{
						
						if ( (data!=('o')) )
						// o is on button so the count for the digit place will be 0 with o 
						//and will need to be incremented with any other push button
						{
							count++;  // count of the digit place
						}
						LCD_write_char(data); // writing the character from data key pad to LCD
						_delay_ms(200); // to avoid repeating writing (try and error)
						
						if (data=='o') // on push botton on key pad
						{
							LCD_write_cmd(0x01); // clear key pad
							count=0; //because the digits places will start from zero again
						}
						
						else if (count==1) // if the first digit is written
						{
							num1tim10=(data-48); // to change from ascii to the number
						
						}
						
						else if (count==2) // if the second digit is written
						{
							num1tim1=(data-48);  // to change from ascii to the number
							
						}
						else if (count==3) // if the third digit is written
						{
							switch (data) // the operation is written in 3rd place
							{
								case '+':
								operation='+';
								break;
								
								case '-':
								operation='-';
								break;
								
								
								case '*':
								operation='*';
								break;
								
								case '/':
								operation='/';
								break;
								
								case '=':
								operation='=';
								break;
							}
						}
						else if (count==4)// first digit of second number (tens)
						{
							num2tim10=(data-48);//from ascii to number
						}
						else if (count==5)// second digit of second number (units)
						{
							num2tim1=(data-48);//from ascii to number
						}
						
						else if (count==6) // it must be = or error will appear
						{
							if (data=='=')
							{
								if (operation=='+')
								{
								//case '+':
									LCD_write_cmd(0xc0); // write the result in the second line on LCD
									LCD_write_number(((num1tim10*10)+num1tim1)+((num2tim10*10)+num2tim1)); // add result display
								}
								
								// 	case '-':
								else if (operation=='-')
								{
									LCD_write_cmd(0xc0); // write the result in the second line on LCD
									num1=((num1tim10*10)+num1tim1); // first number value
									num2=((num2tim10*10)+num2tim1); // second number value
									if (num1>=num2)
									{
									minus=(num1)-(num2);
									LCD_write_number(minus); //positive result if the first number higher than he second
									}
									else
									{
										minus=(num2)-(num1);
										LCD_write_char('-'); // if the second number is larger than the first
										LCD_write_number(minus);
									}										
																		
								}
								else if (operation=='*')
								{
									// case '*':
									LCD_write_cmd(0xc0);
									LCD_write_number((((num1tim10*10)+num1tim1))*(((num2tim10*10)+num2tim1)));
								}
								else if (operation=='/')
								{
									
									
									//case '/':
									
									num1=(num1tim10*10)+num1tim1;
									num2=(num2tim10*10)+num2tim1;
									res=((float)num1)/((float)num2);// casting because the result will be float
									all_digits=res*100; // multiplied by 100 to be Integer number not fraction
									LCD_write_cmd(0xc0); // write on the second line
									LCD_write_number_float((uint16_t)all_digits); //to write the first the numbers before and after the fraction dot
									
								}
								else // if the operation 3rd digit isn't arithmetic
								{
									LCD_write_cmd(0xc0);
									LCD_write_string("error");	
								}

								
							} // end of if (data=='=')
							
							else // if the 6th not =
							{
								LCD_write_cmd(0xc0);
								LCD_write_string("error");
								
							}
						}// end of else if (count==6)
						
						
					}// end of data != 100

				}// end of while mode==3
							
			
		}	// end of if mode ==3
		
		// after mode 3-----------------------------------------------------------------------------------
		else
		{
			LCD_write_cmd(0x01);
			LCD_write_string("end");
			count=0;// return to zero after end
			mode=0; //return to zero after end
		}					
		 
    }// end of while 1
	
}// end of int main


ISR(INT0_vect) // interrupt interrupt of int0 pushbutton 2 on amit kit

{
	CLEARBIT(SREG,7); // disable any interrupt during this interrupt
	
	_delay_ms(50); //to avoid re bouncing
	mode=0;// to avoid any error of modes successful trial
	
	UART_send(count);// send the count to UART (global count)
	_delay_ms(20);
	
	SREG|=(1<<7);// enable interrupt again
		count++;//increment the count
}