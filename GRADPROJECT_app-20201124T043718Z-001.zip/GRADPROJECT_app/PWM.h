/*
 * PWM.h
 *
 * Created: 4/20/2018 4:17:27 PM
 *  Author: Mohab
 */ 


#ifndef PWM_H_
#define PWM_H_
#include "std_macro.h"
uint8_t duty;
//#include <avr/io.h>
//#include "GPIO.h"

void PWM1_OCR1AB_init();
void PWM1_OCR1AB_duty_cycle(uint8_t duty);

/*void PWM2_OCR1B_init();
void PWM2_OCR1B_duty_cycle(uint8_t duty);*/



#endif /* PWM_H_ */