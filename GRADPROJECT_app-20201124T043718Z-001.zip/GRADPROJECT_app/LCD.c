/*
 * LCD.c
 *
 * Created: 4/21/2018 5:07:30 PM
 *  Author: Mohab
 */ 
# include "LCD.h"

void LCD_init()
{
	LCD_INIT_DIR();
	LCD_RW(0);
	LCD_write_cmd(0x2);
	LCD_write_cmd(0x28);
	LCD_write_cmd(0x01);
	LCD_write_cmd(0x0c);
	LCD_write_cmd(0x06);
	LCD_write_cmd(0x80);
	//_delay_ms(20);
	_delay_ms(20);
	
}
void LCD_write_cmd(uint8_t cmd)
{
	LCD_RS(0);
	LCD_D7(READBIT(cmd,7));
	LCD_D6(READBIT(cmd,6));
	LCD_D5(READBIT(cmd,5));
	LCD_D4(READBIT(cmd,4));
	LCD_EN(1);
	//_delay_ms(1);
	_delay_ms(1);
	LCD_EN(0);
	//_delay_ms(1);
	_delay_ms(1);

	LCD_D4(READBIT(cmd,0));
	LCD_D5(READBIT(cmd,1));
    LCD_D6(READBIT(cmd,2));
	LCD_D7(READBIT(cmd,3));
	LCD_EN(1);
	//_delay_ms(1);
	_delay_ms(1);
	LCD_EN(0);
	//_delay_ms(1);
	_delay_ms(1);
}
void LCD_write_char(uint8_t data)
{
	LCD_RS(1);
	LCD_D7(READBIT(data,7));
	LCD_D6(READBIT(data,6));
	LCD_D5(READBIT(data,5));
	LCD_D4(READBIT(data,4));
	LCD_EN(1);
	_delay_ms(1);
	LCD_EN(0);
	//_delay_ms(1);
	_delay_ms(1);
	
	LCD_D4(READBIT(data,0));
	LCD_D5(READBIT(data,1));
	LCD_D6(READBIT(data,2));
	LCD_D7(READBIT(data,3));
	LCD_EN(1);
	//_delay_ms(1);
	_delay_ms(1);
	LCD_EN(0);
	//_delay_ms(1);
	_delay_ms(1);
	
}

void LCD_write_string(uint8_t *data)
{
	uint8_t i=0;
	while(data[i]!= '\0')
	{
		LCD_write_char(data[i]);
		i++;
	}
}

void LCD_write_number(uint16_t number)
//void LCD_write_number(float number)
{uint16_t first,seconed,remain,third,remain1,fourth;
	if (number<10)
	{
		LCD_write_char(number+48);
	}
	else if (number<100)
	{
		first=number/10;
		seconed=number%10;
		LCD_write_char(first+48);
		LCD_write_char(seconed+48);
	}
		else if (number<1000)
		{
			first=number/100;
			remain=number%100;
			seconed=remain/10;
			third=remain%10;
			LCD_write_char(first+48);
			LCD_write_char(seconed+48);
			LCD_write_char(third+48);
		}	
		else if (number<10000)
		{
			first=number/1000;
			remain=number%1000;
			seconed=remain/100;
			remain1=remain%100;
			third=remain1/10;
			fourth=remain1%10;
			
			LCD_write_char(first+48);
			LCD_write_char(seconed+48);
			LCD_write_char(third+48);
			LCD_write_char(fourth+48);
		}
	}	
		
		void LCD_write_number_float(uint16_t number)
		//void LCD_write_number(float number)
		{uint16_t first,seconed,remain,third,remain1,fourth;
			if (number<10)
			{
				LCD_write_char(number+48);
			}
			else if (number<100)
			{
				LCD_write_char('.');
				first=number/10;
				seconed=number%10;
				LCD_write_char(first+48);
				LCD_write_char(seconed+48);
			}
			else if (number<1000)
			{
				first=number/100;
				remain=number%100;
				seconed=remain/10;
				third=remain%10;
				LCD_write_char(first+48);
				LCD_write_char('.');
				LCD_write_char(seconed+48);
				LCD_write_char(third+48);
			}
			else if (number<10000)
			{
				first=number/1000;
				remain=number%1000;
				seconed=remain/100;
				remain1=remain%100;
				third=remain1/10;
				fourth=remain1%10;
				
				LCD_write_char(first+48);
				LCD_write_char(seconed+48);
				LCD_write_char('.');
				LCD_write_char(third+48);
				LCD_write_char(fourth+48);
			}
		}