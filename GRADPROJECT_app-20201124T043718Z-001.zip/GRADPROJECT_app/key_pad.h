/*
 * key_pad.h
 *
 * Created: 4/25/2018 2:53:40 PM
 *  Author: Mohab
 */ 


#ifndef KEY_PAD_H_
#define KEY_PAD_H_
#include <avr/io.h>

//key pad initialization
void key_pad_init();
// key pad scan (get new click
uint8_t key_pad_scan();





#endif /* KEY_PAD_H_ */