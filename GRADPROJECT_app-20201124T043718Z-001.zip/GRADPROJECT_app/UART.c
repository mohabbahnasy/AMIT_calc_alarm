/*
 * UART.c
 *
 * Created: 4/27/2018 5:00:05 PM
 *  Author: Mohab
 */ 

# include "UART.h"

void UART_init()
{
	
	SETBIT(UCSRB,4);//receive
	SETBIT(UCSRB,3);//transmit
	SETBIT(UCSRC,1);//size data 8
	SETBIT(UCSRC,2);// size data 8
	UBRRL=51;// BAOUD rate 9600 8 MHz U2x 0 
	
}

void UART_send(uint8_t data)
{
	while (READBIT(UCSRA,5)==0);
	UDR=data;

}

 uint8_t UART_res()
{
	while (READBIT(UCSRA,7)==0);
     SETBIT(SREG,7);

	return (UDR);
	
}