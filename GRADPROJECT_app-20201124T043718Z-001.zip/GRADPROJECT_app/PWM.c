/*
 * PWM.c
 *
 * Created: 4/20/2018 4:17:06 PM
 *  Author: Mohab
 */ 
#include "PWM.h"
//#include "std_macro.h"

void PWM1_OCR1AB_init()
{
	SETBIT(DDRD,5);//OCR1A is working with DDRD5 LED
	SETBIT(DDRD,4);//Buzzer 
	SETBIT(TCCR1A,COM1A1);// first compare enable oc1a
	SETBIT(TCCR1A,COM1B1);// seconed compare enable oc1b
	//CLEARBIT(TCCR1A,COM1A0);
	TCCR1A|=1<<WGM11|1<<WGM10;
	//TCCR1B|=1<<WGM12|1<<CS10;
	TCCR1B|=1<<WGM12|1<<CS10;
	OCR1A=1000;
	OCR1B=1000;	
}

void PWM1_OCR1AB_duty_cycle(uint8_t duty)
{
	OCR1A=duty*10.23;
	OCR1B=duty*10.23;
}

/*void PWM2_OCR1B_init()
{
	SETBIT(DDRD,4);//OCR1A
	SETBIT(TCCR1B,COM1B1);
	//CLEARBIT(TCCR1A,COM1A0);
	TCCR1A|=1<<WGM12|1<<CS10;
	TCCR1B|=1<<WGM10|1<<WGM11;
	OCR1B=1000;
}

void PWM2_OCR1B_duty_cycle(uint8_t duty)
{
	OCR1B=duty*10.23;
}*/
