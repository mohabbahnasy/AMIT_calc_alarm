/*
 * GRADPR.h
 *
 * Created: 5/11/2018 1:12:03 PM
 *  Author: Mohab
 */ 


#ifndef GRADPR_H_
#define GRADPR_H_
#include <avr/io.h>
# include "ADC.h"
# include "LCD.h"
# include "std_macro.h"
# include "UART.h"
# include "PWM.h"
//# include "task.h"




#endif /* GRADPR_H_ */