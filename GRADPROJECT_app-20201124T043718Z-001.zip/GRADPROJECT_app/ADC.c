/*
 * ADC.c
 *
 * Created: 4/20/2018 7:58:22 PM
 *  Author: Mohab
 */ 
# include "ADC.h"
void ADC_init_0()
{
	//ADMUX|=1<<0 |1<<REFS0;
	ADMUX=1<<REFS0; // ADC 0 enable
	
	ADCSRA|=1<<ADEN |1<<ADPS1 | 1<<ADPS2 | 1<<ADPS0; // ADC customization
}

uint16_t ADC_Read_0(uint8_t channel)
{
	SETBIT(ADCSRA,6);
	while(READBIT(ADCSRA,6)==1)
	{
		
	}
	return ADCL+(ADCH<<8);
}

void ADC_init_1()
{
	ADMUX|=1<<0 |1<<REFS0; //ADC 1 enable
	//ADMUX|=1<<REFS0;
	
	ADCSRA|=1<<ADEN |1<<ADPS1 | 1<<ADPS2 | 1<<ADPS0; //ADC customization
}

uint16_t ADC_Read_1(uint8_t channel)
{
	SETBIT(ADCSRA,6);
	while(READBIT(ADCSRA,6)==1)
	{
		
	}
	return ADCL+(ADCH<<8);
}