/*
 * ADC.h
 *
 * Created: 4/20/2018 7:58:51 PM
 *  Author: Mohab
 */ 

#include <avr/io.h>
#include "std_macro.h"
//#include "PWM.h"
#ifndef ADC_H_
#define ADC_H_

void ADC_init_0();
uint16_t ADC_Read_0(uint8_t channel);

void ADC_init_1();
uint16_t ADC_Read_1(uint8_t channel);



#endif /* ADC_H_ */