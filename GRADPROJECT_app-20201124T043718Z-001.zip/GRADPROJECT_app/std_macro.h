/*
 * std_macro.h
 *
 * Created: 4/7/2018 6:56:57 PM
 *  Author: Mohab
 */ 


#ifndef STD_MACRO_H_
#define STD_MACRO_H_


#include <avr/io.h>
# define F_CPU 8000000UL
# include <util/delay.h>
# include <AVR/interrupt.h>
# include <stdint.h>
# define SETBIT(REG, BIT) REG |=1<<BIT
# define CLEARBIT(REG, BIT) REG &= ~(1<<BIT)
# define TOGBIT(REG, BIT) REG ^= 1<<BIT
# define READBIT(REG, BIT) ((REG>>BIT) & 1)




#endif /* STD_MACRO_H_ */